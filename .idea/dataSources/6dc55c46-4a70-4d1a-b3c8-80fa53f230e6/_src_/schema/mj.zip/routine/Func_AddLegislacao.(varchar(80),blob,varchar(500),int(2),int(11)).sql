CREATE FUNCTION Func_AddLegislacao(titulo VARCHAR(80), pdf BLOB, sumario VARCHAR(500), user INT(2), categoria INT)
  RETURNS VARCHAR(100)
  BEGIN
    INSERT INTO legislacao
    (
      Leg_titulo,
      Leg_pdf,
      Leg_sumario,
      Cat_id

    )
    VALUES
      (
        titulo,
        pdf,
        sumario,
        categoria
      );

    return 'Sucesso';
  END;
