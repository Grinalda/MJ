CREATE FUNCTION Func_AddUser(nome VARCHAR(20), email VARCHAR(20), pass VARCHAR(32))
  RETURNS VARCHAR(20)
  BEGIN
    insert into user (User_Nome, User_email, User_Password) values(nome, email, md5(pass));
    RETURN "true;sucessso";
  END;
