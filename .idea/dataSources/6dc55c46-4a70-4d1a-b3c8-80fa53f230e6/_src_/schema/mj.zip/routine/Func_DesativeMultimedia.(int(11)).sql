CREATE FUNCTION Func_DesativeMultimedia(id INT)
  RETURNS VARCHAR(100)
  BEGIN
    UPDATE multimedia
      SET estado = 0
    WHERE multimedia.Mult_id = id;
  RETURN "Sucesso";
  END;
