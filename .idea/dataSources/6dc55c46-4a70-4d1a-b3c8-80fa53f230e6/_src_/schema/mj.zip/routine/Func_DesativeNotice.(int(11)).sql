CREATE FUNCTION Func_DesativeNotice(id INT)
  RETURNS VARCHAR(100)
  BEGIN
    UPDATE noticia
    SET Noticia_estado = 0
    WHERE noticia.Noticia_id = id;
    RETURN "Sucesso";
  END;
