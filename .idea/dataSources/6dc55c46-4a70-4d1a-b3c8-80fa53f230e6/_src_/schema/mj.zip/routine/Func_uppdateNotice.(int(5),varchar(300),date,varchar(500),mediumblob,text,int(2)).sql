CREATE FUNCTION Func_uppdateNotice(id   INT(5), titulo VARCHAR(300), date_Noticia DATE, resumo VARCHAR(500),
                                   foto MEDIUMBLOB, conteudo TEXT, user INT(2))
  RETURNS VARCHAR(100)
  BEGIN
    UPDATE noticia
      SET Noticia_titulo = titulo,
          Noticia_data = date_Noticia,
          Noticia_resumo = resumo,
          Noticia_foto = foto,
          Noticia_texto = conteudo,
          User_User_id = user
    WHERE Noticia_id = id;
  RETURN 'Sucesso';
  END;
