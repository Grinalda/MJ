CREATE VIEW ver_legislacao AS
  SELECT
    `leg`.`Leg_titulo` AS `titulo`,
    `cat`.`Cat_nome`   AS `categoria`,
    `leg`.`Leg_date`   AS `data`
  FROM (`mj`.`legislacao` `leg`
    JOIN `mj`.`categoria_legislacao` `cat`)
  WHERE (`leg`.`Leg_estado` = 0);
