CREATE VIEW ver_multimedia AS
  SELECT `multi`.`Mult_conteudo` AS `conteudo`
  FROM `mj`.`multimedia` `multi`
  ORDER BY `multi`.`Mult_dataReg` DESC;
