CREATE VIEW ver_multimedia AS
  SELECT
    `multi`.`Mult_conteudo` AS `conteudo`,
    `multi`.`Mult_dataReg`  AS `data`,
    `multi`.`Mult_id`       AS `id`
  FROM `mj`.`multimedia` `multi`
  WHERE (`multi`.`estado` = 1)
  ORDER BY `multi`.`Mult_dataReg` DESC;
